# Node_API_CRUD

<img width="830" alt="CRUD-Operations-Rest-API" src="https://user-images.githubusercontent.com/70806481/147379710-06be25be-fce2-4cf3-88fa-ffd64bc46802.png">
